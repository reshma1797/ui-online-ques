import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homedash',
  templateUrl: './homedash.component.html',
  styleUrls: ['./homedash.component.css']
})
export class HomedashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
