import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { HomedashComponent } from './homedash/homedash.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { MentorsearchComponent } from './mentorsearch/mentorsearch.component';
import { MentorhomeComponent } from './mentorhome/mentorhome.component';
import { MentornavComponent } from './mentornav/mentornav.component';
import { MentorprogressComponent } from './mentorprogress/mentorprogress.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    HomeComponent,
    HomedashComponent,
    LoginComponent,
    SignupComponent,
    MentorsignupComponent,
    MentorsearchComponent,
    MentorhomeComponent,
    MentornavComponent,
    MentorprogressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
