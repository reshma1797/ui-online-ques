import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentorhome',
  templateUrl: './mentorhome.component.html',
  styleUrls: ['./mentorhome.component.css']
})
export class MentorhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
